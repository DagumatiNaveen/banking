public class Hdfc implements Bank{
    private String name;
    private  String accountno;
    private int balance;
    private String password;
    private double rateofinterest=2.0;

    public Hdfc(String accountno, String name) {
        this.accountno = accountno;
        this.balance = balance;
        this.name = name;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAccountno() {
        return accountno;
    }

    public void setAccountno(String accountno) {
        this.accountno = accountno;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public double getRateofinterest() {
        return rateofinterest;
    }

    public void setRateofinterest(double rateofinterest) {
        this.rateofinterest = rateofinterest;
    }

    @Override
    public int getbalance() {
        return this.balance;
    }
    @Override
    public int deposit(int amount) {

        this.balance+=amount;

        return amount;
    }
    @Override
    public int withdraw(int amount,String password) {
        
        this.balance-=amount;
        return amount;
    }
    @Override
    public double interest(int time) {
        return (rateofinterest*balance*time)/100;
    }
}
