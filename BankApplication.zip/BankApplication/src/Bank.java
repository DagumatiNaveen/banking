public interface Bank {

    int getbalance ();
    int deposit(int amount);
    
    int withdraw(int amount,String password);
     
    double interest(int time);
}
