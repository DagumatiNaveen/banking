public class SbiAccount implements Bank{

    @Override
    public int getbalance() {
        return 0;
    }

    @Override
    public int deposit(int amount) {
        return 0;
    }
    @Override
    public int withdraw(int amount,String password) {
        return 0;
    }

    @Override
    public double interest(int time) {
        return 0;
    }
}
