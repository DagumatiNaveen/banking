import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        Scanner sc=new Scanner(System.in);
        String name=sc.next();
        Hdfc hd=new Hdfc("1234",name);
        System.out.println(" deposit balance "+hd.deposit(100));

        System.out.println("current balance"+hd.getBalance());

        System.out.println("withdraw"+hd.withdraw(100,name));

        System.out.println("After current balance"+hd.getBalance());



    }
}